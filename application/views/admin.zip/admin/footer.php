<!--Footer-part-->
<div class="row-fluid">
    <div id="footer" class="span12">© All rights are reserved to Dcount now 2017-2018 : Powered by : Irebel Webtech
    </div>
</div>
<!--end-Footer-part-->
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.ui.custom.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.uniform.js"></script>
<!--<script src="<?php echo base_url(); ?>assets/js/select2.min.js"></script>-->
<script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/matrix.js"></script>
<script src="<?php echo base_url(); ?>assets/js/matrix.tables.js"></script>


<script>
    $(document).ready(function () {

        $("#dash").click(function () {
            $(this).addClass("active");
        });
    });
</script>

</body>
</html>
