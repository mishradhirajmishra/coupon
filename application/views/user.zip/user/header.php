<!DOCTYPE html>
<html lang="zxx">


<!-- Mirrored from xentora.com/kobone-html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 10 Nov 2017 08:59:26 GMT -->
<head>
<title>Dcount Now - Grab discount near lucknow</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!--google meta-->
	<meta name="google-signin-scope" content="profile email">
   <meta name="google-signin-client_id" content="441150461450-6snrhh2qacjjfjkgmbcf3lde4k4camud.apps.googleusercontent.com">
    
	<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="Description" content="Free Web coupon discount dcount store percentage">
<meta name="Keywords" content="dcount coupon store category lucknow  discount">
    <meta name="author" content="dhiraj">
    <META NAME="robots" CONTENT="dcount coupon store category lucknow  discount">
    <meta name="title" content="Page title">
    <meta name="google-site-verification" content="1SOK6VLmHm0-fd4qYYXiUPwskwLJ53Cg1i5lKaSUF6g" />
	<title>Dcount Now - Grab discount near you</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
	<!-- Standard -->
	<link rel="shortcut icon" href="<?php echo base_url();?>assets/user/images/ficon1.jpg">
	<!-- Bootstrap Core CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/user/css/bootstrap.min.css" type="text/css">
	<!-- Dropdownhover CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/user/css/bootstrap-dropdownhover.min.css" type="text/css">
	<!-- fonts awesome -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
    <!-- Plugin CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/user/css/animate.min.css" type="text/css">

	<!-- Custom CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/user/css/style.css" type="text/css">
	<!-- Owl Carousel <?php echo base_url();?>assets/user -->
	<link href="<?php echo base_url();?>assets/user/owl-carousel/owl.carousel.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/user/owl-carousel/owl.theme.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/user/owl-carousel/custom.css" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <style>

span#f1 {
    border: 1px solid #4285f4;
    padding: 0px 11px;
    font-size: 24px;
    font-weight: 800;
    background-color: white;
    color: #4285f4;
}


span#f2 {
    background-color: #4285f4;
    color: white;
  
    padding-top: 8px;
    padding-bottom: 7px;
    padding-right: 29px;
}
     .featured-coupons-images1 {

    background: red; /* For browsers that do not support gradients */
    background: linear-gradient(to right,  #002b5e, #337ab7); /* Standard syntax (must be last) */
}

.rate5{

 background: radial-gradient(#002b5e, #337ab7,#002b5e, #337ab7);

    /*border: 2px solid black;*/
    border-radius: 50px;
    padding: 26px 12px;
    float: right;
    color: white;
    /* margin: auto; */
    margin-top: 1%;
    margin-right: 1%;}

.featured-coupons-images1 {
    border-bottom: 1px solid #dddddd;
    float: left;
    /*background-color: #002b5e;*/
    margin-bottom: 15px;
    text-align: center;
    width: 100%;
}

img.logomain {
    margin-left: 10%;
    margin-top: 8px;
    height: 45px;
}
@media only screen and (max-width: 767px) {
img.logomain {
    margin-left: 10%;
    margin-top: -2px;
    height: 45px;
}
}
     .featured-coupons-images {
    overflow: hidden;
}
a.btn.chview {
    width: 100%;
}
      @media screen and (max-width: 767px) {
           .featured-coupons-images {
 
           height: 190px!important;
               
           }
 }

     span.c_cop {
    color: black;
}
     p.c_head {
    font-weight: 800;
    color: black;
      text-align: center;
}
     

.thumbnail{
    /* Add shadows to create the "card" effect */
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.thumbnail:hover {
    box-shadow: 0 80px 160px 0 rgba(0,0,0,0.2);
}
p.c_head {
    height: 52px;
}
/*****************/
  .heig {
    height: 64px;
}
     @media screen and (max-width: 767px) {
         img.logomain {
    margin-left: 38%;
         }
       .heig{height:87px;}
       .header-search {
    display: none;
}
     }
     

    a.btn.btn-default.btnchreg{
        color: white;
    background: -webkit-linear-gradient(left top, orange,red);
    background: -o-linear-gradient(bottom right,orange,red);
    background: -moz-linear-gradient(bottom right,orange,red);
    background: linear-gradient(to bottom right, orange,red);
    }
     p.forg {
    margin-top: 10px;
    color: yellow;
    font-size: 19px;
   
}
a.forg-in {
    color: red;
}
         input.btn.btn-primary.ser {
    padding: 4px;
    margin-bottom: 3px;
    font-size: 26px;
}
.w_social {
    position: relative;
    width: 252px;
    margin: auto;
}

 @media screen and (min-width: 768px){
.featured-coupons-text h6 { height: 56px;}
.featured-coupons-text p { height: 56px;}
}
/*)))))))))))))))*/
/* Shared */
.loginBtn {
  box-sizing: border-box;
  position: relative;
  margin: 0.1em;
  padding: 2px 29px 2px 44px;
  border: none;
  text-align: left;
  line-height: 34px;
  white-space: nowrap;
  
  font-size: 13px;
  color: #FFF;
}
.loginBtn:before {
  content: "";
  box-sizing: border-box;
  position: absolute;
  top: 0;
  left: 0;
  width: 34px;
  height: 100%;
}
.loginBtn:focus {
  outline: none;
}
.loginBtn:active {
  box-shadow: inset 0 0 0 32px rgba(0,0,0,0.1);
}


/* Facebook */
.loginBtn--facebook {
        font-size: 13px;
    text-align: center;
    width: 249px;
 
  margin-left: 0px;
  background-color: #4C69BA;
  background-image: linear-gradient(#4C69BA, #3B55A0);
  /*font-family: "Helvetica neue", Helvetica Neue, Helvetica, Arial, sans-serif;*/
  text-shadow: 0 -1px 0 #354C8C;
}
.loginBtn--facebook:before {
  border-right: #364e92 1px solid;
  background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/icon_facebook.png') 6px 6px no-repeat;
}
.loginBtn--facebook:hover,
.loginBtn--facebook:focus {
  background-color: #5B7BD5;
  background-image: linear-gradient(#5B7BD5, #4864B1);
}

/*dcount*/
.loginBtn--dcount {
  background-color: #4C69BA;
/*  background-image: linear-gradient(#4C69BA, #3B55A0);*/
  /*font-family: "Helvetica neue", Helvetica Neue, Helvetica, Arial, sans-serif;*/
  text-shadow: 0 -1px 0 #354C8C;
}
.loginBtn--dcount:before {
  border-right: #364e92 1px solid;
  background: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/14082/icon_facebook.png') 6px 6px no-repeat;
}
.loginBtn--dcount:hover,
.loginBtn--dcount:focus {
  background-color: #5B7BD5;
  background-image: linear-gradient(#5B7BD5, #4864B1);
}
.head_c {
    border: 1px solid;
    padding: 4px;
    border-radius: 17px;
    text-align: center;
}
head_c.collapsed {
    text-align: center;
}

/*model css*/
.login_modal_footer{margin-top:5px;}
.login_modal_header .modal-title {text-align: center;font-family:'Philosopher',sans-serif; }
.form-group{position: relative;}
.form-group .login-field-icon {
    font-size: 20px;
    position: absolute;
    right: 15px;
    top: 3px;
    transition: all 0.25s ease 0s;
    padding-top: 2%;
}
.login-modal{
    width:100%;
    padding-bottom:20px;
}
.login_modal_header, .login_modal_footer {background: #002b5e !important;color:#fff;}
.modal-register-btn{
         text-align: center;
    margin-top: 20px;
}
.login-modal input{height:40px; box-shadow: none; border:1px solid #ddd;}
@media only screen and (min-width: 768px) {
.modal-body-left{float:left; width:50%; padding-right:4%; border-right:4px solid #ddd;}
.modal-body-right{float:right; width:47%;}
.modal-dialog {
    margin-top: 10%;
}
.w_social {
    top: 7px;
}
}

@media only screen and (max-width: 767px) {
.ggg{margin-left: 38.5%;}
}

i.fa.fa-lock.login-field-icon,i.fa.fa-user.login-field-icon {
    color: #002b5e;
}

.login-link{padding:0 20%;}
.modal-social-icons{padding:0 10%;}
.facebook, .twitter, .google, .linkedin {width:100%;height:40px; padding-top:2%; margin-top:2%;}
.modal-icons{margin-left: -10px; margin-right: 20px;}
.google, .google:hover{background-color:#dd4b39;border:2px solid #dd4b39;color:#fff;}
.twitter, .twitter:hover{ background-color: #00aced; border:2px solid #00aced;color: #fff;}
.facebook, .facebook:hover{background-color: #002b5e; border:2px solid #3b5999;color:#fff;}
.linkedin, .linkedin:hover{background-color: #007bb6; border: 2px solid #007bb6; color:#fff;}
#social-icons-conatainer{position: relative;}
#center-line{position: absolute;  right: 270.7px;top: 80px;background:#ddd;  border: 4px solid #DDDDDD;border-radius: 20px;}
.modal-login-btn{width:100%;height:40px; margin-bottom:10px;}
#modal-launcher{margin: 30% 0 0 30%; }
.btn-success:hover, .btn-success:focus, .btn-success.focus, .btn-success:active, .btn-success.active, .open>.dropdown-toggle.btn-success {
    color: #fff;
    background-color: #002b5e;
    border-color: #002b5e;
}
.btn-success {
    color: #fff;
    background-color: #002b5e;
    border-color: #002b5e;
}
button.loginBtn.loginBtn--facebook {
    margin-bottom: 17px;
}

.frofile{    width: 100%;}
  .modal-body {
    background-color: #002b5e;
}

   </style>
     <!--google login-->

    <script src="https://apis.google.com/js/platform.js" async defer></script>
     <!--/google login-->
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-110575613-1');
</script>

</head>

<body>
    <!--****************************************************FACEBOOK LOGIN******************************************************************-->
<div id="fb-root"></div>

    
    <!--****************************************************FACEBOOK LOGIN******************************************************************-->

	<header class="hide-bg">
		<!-- header -->
		<div id="mainNav" class="navbar-fixed-top">

			<div class="container-fluid" style="background: #002b5e;">
			    <!---->
				<div class="col-xs-12 col-sm-1 col-md-1 chlogo" style="padding-right: 0px !important;padding-left: 0px !important">
				    
					<div class="abc"><a   href="<?php echo base_url();?>home"> <img class="logomain"  src="<?php echo base_url("assets/img/Dcount.png") ?>" alt="logo"></a> </div>
				</div>
				<div class="col-xs-12 col-sm-3 col-md-3">
					<div class="header-search">
					    <?php  echo form_open('User/search');?>
						<input style="    height: 35px;" name="search_name" type="text" placeholder="Search For Coupons... " required>
						<input     style="    padding: 0px;" type="submit" class="btn btn-primary ser" Value="Go"><!--<i class="fa fa-search" aria-hidden="true"></i></a>-->
						</form>
					</div>
				</div>
				<div class="col-xs-12 col-sm-8 col-md-8">
					<!--  nav  -->
					<nav class="navbar navbar-inverse navbar-default">
                    
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
                        
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" data-hover="dropdown" data-animations=" fadeInLeft fadeInUp fadeInRight">
                            <ul class="nav navbar-nav">
                              <li class="menu-item"><a href="<?php echo base_url();?>home" class="">HOME</a></li>
                              <li><a href="<?php echo base_url();?>allstore">STORE</a></li>
                               <li class="menu-item dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">CATEGORIES</a>
                                <ul class="dropdown-menu">
                                   <?php foreach( $category as $row){?>
                                	<li><a href="<?php echo base_url();?>category/<?php echo $row['cat_id'] ?>/<?php echo strtolower($row['cat_name']); ?>"><?php echo $row['cat_name'];?></a></li>
                                   <?php } ?>
                                </ul>
                              </li>
                              <!--<li><a href="<?php //echo base_url();?>user/view_all_recent">LATEST</a></li>-->
                              <!--<li class="dropdown">
                                    <a href="index-2.html" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span>NEWS</span></a>
                                    <ul class="dropdown-menu dropdownhover-bottom" role="menu">
                                        <li><a href="news.html">News</a></li>
                                        <li><a href="single-news-page.html">Single News Page</a></li>
                                    </ul>
                                </li>-->
                                <li><a href="<?php echo base_url();?>howitwork">HOW IT WORK</a></li>
                                 <li class="dropdown">
                                    <a href="<?php echo base_url();?>user/about" data-toggle="dropdown" role="button" aria-expanded="false"><span>ABOUT</span></a>
                                    <ul class="dropdown-menu dropdownhover-bottom" role="menu">
                                       
                                           <li><a href="<?php echo base_url();?>aboutus">ABOUT</a></li>
                                              <li><a href="<?php echo base_url();?>contactus">CONTACT</a></li>
                                        
                                    </ul>
                                </li>
                                <?php if(array_key_exists("user_role",$_SESSION)){}else{
                                        $this->load->library('session');
        $user_data = array('username' => "xxxx", 'user_role' => "xxxx", 'loged_in' => false);
           $this->session->set_userdata($user_data);
                                
                                } ?>
                                <?php if(array_key_exists("user_role",$_SESSION) && $_SESSION['user_role']=="user" ){ 
                                    ?>
                                    
                                    <!---->
                                                                    <li class="menu-item dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">PROFILE</a>
                                <ul class="dropdown-menu">
                                     <li><a href="<?php echo base_url();?>user/list_user_coupon" > <?php echo $_SESSION['username'] ?></a></li>
                                    <li onclick="g_logout()"><a  href="<?php echo base_url();?>user/logout" onclick="g_logout()" >LOGOUT</a></li>
                                  </ul>
                                  </li>
                                    
                                    <!---->
  
                                <?php 
                                    
                                }else{
                                echo '<li><a href="#" data-toggle="modal" data-target="#login-modal">LOGIN</a></li>';
                                ?>
                                    
<!--                               <li class="menu-item dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">LOGIN</a>
                                <ul class="dropdown-menu">-->
<!--                              <li><a  href="#" >&nbsp;<button style="border-radius:0px;width:100px" type="button" class="btn btn-primary" ><b>D</b>Sign in</button></a></li>
-->                              
                           <!--   <li><a><img style="width:121px" data-toggle="modal" data-target="#myModal2" src="<?php echo base_url();?>assets/dddd.jpg">
                              <li><a><button onclick="logIn()" class="loginBtn loginBtn--facebook">&nbsp;&nbsp;Sign in with Facebook </button></a></li>
                              <li onclick="g_login()"> <a href=""><div  class="g-signin2" data-onsuccess="onSignIn" data-width="250" data-height="38" data-longtitle="true"  data-theme="dark"></div></a></li>
                            </ul>
                              </li>-->
                                <?php
                                } 	?>
                             
                           <!---->
                                   <!-- Trigger the modal with a button -->
            
  <!-- Trigger the modal with a button -->
  <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
    	<div class="modal-content">
      		<div class="modal-header login_modal_header">
        		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        		<h4 class="modal-title" id="myModalLabel">Login to Your Account</h4>
      		</div>
      		<div class="modal-body login-modal" style="background-color:white;">
      		
      			<br/>
      			<div class="clearfix"></div>
      			<div id='social-icons-conatainer'>
	        		<div class='modal-body-left'>
                    
               
							 <ul class="nav nav-tabs">
							<li class="active" style="width:50%"><a data-toggle="tab" href="#home">Sign in</a></li>
							<li style="width:50%"><a data-toggle="tab" href="#menu1">Sign up</a></li>
						     </ul>
						  
						   <div class="tab-content">
                           <div id="home" class="tab-pane fade in active">
                         <br>
                     <?php  echo form_open('User/sign_in');?>   
  	        			<div class="form-group">
  	        	      		<input name="form-name" type="text" placeholder="Name..." value="" class="form-control login-field">
		              		<i class="fa fa-user login-field-icon"></i>
		            	</div>
		
		            	<div class="form-group">
		            	  	<input type="password" name="form-pass" placeholder="Pass..." value="" class="form-control login-field">
		              		<i class="fa fa-lock login-field-icon"></i>
		            	</div>
		            	<input class="btn btn-success modal-login-btn" type="submit" value="Login!">
						</form>
						</div>
                     						
						<div id="menu1" class="tab-pane fade">
						    <br>
				           <?php  echo form_open('User/signup_user');?>
  	        			<div class="form-group">
		              		<input type="text" name="form-name" placeholder="Name..." value="" class="form-control login-field">
		              		<i class="fa fa-user login-field-icon"></i>
		            	</div>
		
		            	<div class="form-group">
		            	  	<input type="email" name="form-email" placeholder="Email..." value="" class="form-control login-field">
		              		<i class="fa fa-lock login-field-icon"></i>
		            	</div>
		
		            		<input class="btn btn-success modal-login-btn" type="submit" value="Register!">
						</form>
							</div>
							 <p class="">Forgot Password ?...<a href="<?php echo base_url();?>user/recovery" class="forg-in">Click Here</a></p>	
						  </div>
						
                        
                        
	        		</div>
	        	
	        		<div class='modal-body-right'>
	        		 	<div class="modal-social-icons1">
	        			   <div class="w_social">
                    <a><button onclick="logIn()" class="loginBtn loginBtn--facebook">&nbsp;&nbsp;Sign in with Facebook </button></a></li>
                    <a href=""><div  class="g-signin2" data-onsuccess="onSignIn" data-width="250" data-height="38" data-longtitle="true"  data-theme="dark"></div></a>
                       <br>
                       <a href="http://dcountnow.com/index.php/dcount/login"><button class="btn btn-success modal-login-btn">Store Login</button></a> 
                       <br>
                        <a href="http://dcountnow.com/index.php/dcount/addstore"><button class="btn btn-success modal-login-btn">Store Sign Up</button></a> 
	        		      </div>	
	        		</div>
	        	</div>																												
        		<div class="clearfix"></div>
        		
 	<!--	<div class="form-group modal-register-btn">
        		 <p></p>
        		
        		</div>-->
      		</div>
      		<div class="clearfix"></div>
      		<div style="text-align:center">
      		    <p style="color: black;  border-top: 1px solid lightgray;
    margin-top: 6px;">By logging in, you agree to Dcountnow <span style="color: red;">Terms Of Service</span> and <span style="color: red;">Privacy Policy</span>.</p>
      		</div>
    	</div>
  	</div>
</div>

                                   

  <!-- Trigger the modal with a button -->
                         
                                   <!-- Trigger the modal with a button -->
                         
                                
                                  <!-- Modal -->
                                  <div class="modal fade" id="myModal2" role="dialog">
                                    <div class="modal-dialog modal-sm">
                                      <!-- Modal content-->
                                      <div class="modal-content">
                                        <div class="modal-body">
                                        <!-- login -->
                                         <div class="form-box">
                                    		<div class="form-top">
            	                        		<div class="form-top-left">
            	                        			<h3 class="head_c">Login <i class="fa fa-pencil"></i></h3>
            	                        		</div>

            	                            </div>
            	                            <div class="form-bottom">
                                       <?php  echo form_open('User/sign_in');?>   
                                            <div class="form-group">
            				                       	<label class="sr-only" for="form-email">Name</label>
            				                        	<input type="text" name="form-name" placeholder="Name..." class="form-email form-control" id="form-name">
            				                        </div>
            				                        
            				                        <div class="form-group">
            				                        	<label class="sr-only" for="form-about-yourself">Password</label>
            				                        	<input  type="password" name="form-pass" placeholder="Pass..." class="form-email form-control" id="form-pass">
            				                        </div>
            				                        <button type="submit" class="btn btnch4">Login!</button>
            				                    </form>
            				                    <p class="forg">Forgot Password ?...<a href="<?php echo base_url();?>user/recovery" class="forg-in">Click Here</a></p>
            			                    </div>
                                    	</div>
                                        <!-- login close-->
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                              <!---->

                            </ul>
                            <!-- /.navbar-collapse -->
                            <!-- /.navbar-collapse -->
                        </div>
					</nav>
					<!--  /nav  -->
					<!-- search-popup -->
			
					<!-- /search-popup -->
				</div>
			</div>
		</div>
		<div class="heig">
		    
		</div>

		<h1 Style="display: none;">Dcount Now</h1>
		<div id="top123"></div>
							    <?php    $query = $this->db->get_where('user',array('name'=>$_SESSION['username'])); $res=$query->row_array(); $mono=$res['mo_no']; ?>
		<!-- /header -->
		
