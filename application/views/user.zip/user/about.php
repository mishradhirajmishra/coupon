<style>
    .map2 {
    border: 1px solid rgb(221, 221, 221);
    height: 400px;
    position: relative;
    width: 100%;
    z-index: -1;
   
}


.ab{   text-align:justify;margin-bottom:20px;font-family: "Helvetica Neue",Helvetica,Arial,sans-serif !important;color: white!important;}
.wrap0 {
    
 
}
  
    margin-bottom: 10px;
    border: 1px solid gray;
    padding: 20px;
    border-radius: 5px;
    font-size: 15px;
   font-family: "Helvetica Neue",Helvetica,Arial,sans-serif !important;
}
.contact-info2 {
    background: rgb(0, 43, 94) none repeat scroll 0 0;
    color: rgb(255, 255, 255);
    /* margin-top: 94px; */
    padding: 24px;
}
</style>

<!-- header bg -->
		<div class="inner-bg">
			<div class="container">
				<div class="inner-text">
					<h1 class="wow slideInDown" data-wow-delay="300ms" data-wow-duration="1500ms">About <span>Us</span></h1>
					<ul>
						<li><a href="#"><i class="fa fa-home" aria-hidden="true"></i></a></li>
						<li>/</li>
						<li><a href="#">About Us</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- header bg end -->
	</header>
	<section class="list-store">
		<!-- list-store -->
		<div class="container">
		    <!---->
		    <div class="row">	
            <div class="col-md-12">
                 						<!-- title -->
					<div class="tilte">
						<h2>ALL ABOUT <span>DCOUNT NOW</span></h2>
					
							
					</div>
					<!-- /title -->
				</div></div>
		    <!---->
				<div class="col-sm-8 col-md-8">
					<div class="row">
					    	<div class="wrap0 contact-info"style="    margin-top: 0px !important;">


<P  class="ab">Fashion,   glitters, festivities? We welcome you to Dcount Now for attractive coupons at sparkling prices!</P>

<P class="ab">Lucknow has its entirely new venture of all the creative heads coming together to satiate your appetite for shopping.

Our team has experts who are willing to work with unorganized market structure and preventing them from entering the ongoing online trends of shopping. 

Coaching centers, Hospitals, medical stores, education centers, beauty clinics and everything come under the umbrella of Dcount Now.</P>

<P class="ab">We deal with all possible amenities, daily commodities, entertainment, to give you the best we could!</P>

<P class="ab">Discount coupons are the most loveable entities for all! Dcount Now aims to provide the shopping freaks with unbelievable offers on a huge variety of essentials. 
We would not like your wardrobes to crave for being overloaded with fashion, colors and fun! We will love to be your partner in shopping at affordable prices.
We bring amazing deals and coupons to you every single day. Dcount Now understands your shopping desires and serves you with deals you have never seen before!</P>



<P class="ab">Let us introduce you to the world of Discounts and "Dcount Now".<P>

<P class="ab">Who doesn't like a good  deal ? A bargain that acts as a deciding factor as to whether you will or will not buy that fancy new handbag or maybe an amazing 
pair of sports shoes? Wouldn't it be amazing if you got such great bargains at a completely local level  ? 
Deals not just on goods, but for services used by you on a daily basis such as education centers , salons, medical stores, general stores. Sounds good doesn't it?</P>


<P class="ab">Welcome to the world of Dcount Now! Your one stop app for attractive deals, bargains in the form of discount coupons.

We are an entirely new venture in Lucknow comprising of creative heads with just one aim- To help end your search for the best discounts for pretty much everything.

Coaching/ education centers, hospitals, medical stores, education, beauty clinics, salons, you name it and we have a coupon for you!</P>



					</div>
							</div>
				</div>
				<div class="col-sm-4 col-md-4">
				    
					<!-- contact-info -->
					<div class="contact-info"style="    margin-top: 0px !important;">
						<h4>additional info</h4>
						<P>Our team of experts strive to work with not only big popular brands but also the unorganized / local market structure and provide you with discount coupons for all
possible amenities, daily commodities, entertainment, services and much more.</P>

<P >So join the Dcount team!

Let us serve you with the very best.

Get a coupon . Just Dcount Now!<P>
						<h4>street address</h4>
						<p>1/108, Gomti Nagar Bypass Rd, Vijay Khand, Vishal Khand 1, Vishal Khand, Gomti Nagar, Lucknow, Uttar Pradesh 226010.
							</p>
						<h4>contact</h4>
						<ul>
							<li><i class="fa fa-mobile" aria-hidden="true"></i> 7379404444 </li>
							<li><i class="fa fa-phone" aria-hidden="true"></i> 0522-4231084</li>
							<li><i class="fa fa-envelope" aria-hidden="true"></i> dcountnow@gmail.com</li>
							
						</ul>
						<br>	<br>	<br>	<br>	<br>	
					</div>
					<!-- /contact-info -->
				</div>
			</div>
		</div>
		<br>
               <div class="weight">
                        <div class="deal-box1">
                           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.4882054644927!2d80.98318231463467!3d26.856225983151965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399be2ef9d070a45%3A0x8897302348519c56!2sDcountNow!5e0!3m2!1sen!2sin!4v1515672522739" width="1920" height="400" frameborder="0" style="border:0" allowfullscreen></iframe></div>
						<!-- /map end -->
                        </div>
                    </div>
	</section>
